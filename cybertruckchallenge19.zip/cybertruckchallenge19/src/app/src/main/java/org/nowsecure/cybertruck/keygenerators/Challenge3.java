package org.nowsecure.cybertruck.keygenerators;

public class Challenge3 {
    public Challenge3() {
    }

}
